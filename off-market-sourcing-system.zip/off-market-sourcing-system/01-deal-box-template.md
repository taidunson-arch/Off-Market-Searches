# Deal Box Template

Fill every field. The agent applies this at every stage; blanks become noise.

## Mandate

- **Asset type:** (e.g. multifamily 20-80 units / neighborhood retail / light industrial)
- **Vintage:** (e.g. 1975-2005)
- **Deal size:** (e.g. $2M-$12M)
- **Target submarket:** (boundary description or map link; be specific)
- **Return target:** (e.g. 7%+ stabilized yield, value-add to 12% IRR)

## Owner profile

- **Keep:** LLCs, trusts, family-owned entities, long-hold individuals (10y+)
- **Drop:** REITs, institutions, funds, merchant builders
- **Signals worth ranking up:** out-of-state owner, recent loan maturity,
  long hold with low basis, deferred maintenance visible

## Hard no's

- (e.g. flood zone, ground lease, pre-1960 unreinforced masonry, environmental flags)

## Sponsor fit

- One paragraph: who you are, what you close on, proof you close. The agent
  uses this in outreach drafts so owners hear a credible buyer, not a list blast.
