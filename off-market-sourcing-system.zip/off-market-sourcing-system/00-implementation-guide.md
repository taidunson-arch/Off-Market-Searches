# The CRE Off-Market Sourcing Agent: Implementation Guide

**Pack:** The Off-Market Sourcing System
**By:** NextAutomation, nextautomation.us
**Version:** 1.0 (June 2026)

---

## What this is

This is an AI sourcing agent we built for commercial real estate acquisition work. You hand it three things: a deal box, your internal valuation template, and a few comps you trust. It hands back a ranked list of off-market opportunities: every qualifying parcel in the submarket, the human being behind every LLC, verified contact details, a comp-based value on each asset, and a personalized outreach kit for every property.

The numbers in this guide come from real runs, not projections:

- **200+ off-market owners** sourced in one submarket in **38 minutes**.
- BOV and memo drafts with comp maps for the **top 5 targets in another 15 minutes**.
- The same list-building done by hand takes an analyst **2 to 3 weeks**.

This pack gives you the architecture and the working materials to replicate the workflow with Claude: the deal box template, the seven production prompts, the outreach templates, the data source map, and the human verification checklist.

One honest note before anything else. The agent is good. It is not magic. Every output passes through a human review gate before a single letter gets mailed. That gate is part of the system design, not an apology for it.

The production system runs on Claude with a custom data architecture, built alongside ex-Goldman engineers and data-infrastructure specialists. What follows is the same logic, packaged so you can run it yourself.

---

## What you need before you start

Three inputs and two kinds of access.

**Inputs (you provide these once per deal box):**

1. **A completed deal box.** Asset type, vintage, deal size, target submarket, owner profile, return target, hard no's. File `01-deal-box-template.md` walks you through it. This is the single highest-leverage input: a sloppy deal box produces a long list of properties you don't want.
2. **Your internal valuation template.** Whatever methodology you already underwrite with: price per unit, price per square foot, cap rate on in-place income, your adjustment categories. The agent applies your method, it does not impose one.
3. **Three to five trusted comps.** Recent trades or leases you personally believe. These anchor the agent's comp selection so it calibrates against your read of the market, not a generic one.

**Access (ongoing):**

4. **Parcel and ownership data** for your target submarket: your county assessor portal, GIS open-data export, or your data provider.
5. **A contact enrichment or skip-trace provider** that returns emails and phone numbers with verification flags. Any reputable provider in this category works; the prompts treat it as a pluggable input.

And Claude itself. More on the model tier below.

---

## Architecture overview

```
                          YOUR INPUTS
   +--------------+  +---------------------+  +------------------+
   |   Deal box   |  | Internal valuation  |  |  3-5 trusted     |
   |  (file 01)   |  |      template       |  |     comps        |
   +------+-------+  +----------+----------+  +--------+---------+
          |                     |                       |
          +----------+----------+-----------+-----------+
                     |
                     v
   +---------------------------------------------------------+
   |    SOURCING AGENT  (Claude + orchestration layer)       |
   |                                                         |
   |  Stage 1  Parcel pull        <-- county/assessor data   |
   |  Stage 2  Entity filter                                 |
   |  Stage 3  LLC skip-trace     <-- secretary of state,    |
   |                                  recorder/deeds         |
   |  Stage 4  Owner enrichment   <-- enrichment provider    |
   |  Stage 5  Comp valuation     <-- comps sources          |
   |  Stage 6  Outreach drafting                             |
   |  Stage 7  Self-verification                             |
   +---------------------------+-----------------------------+
                               |
                               v
        Ranked owner list + valuations + outreach kit
                               |
                               v
                  +-------------------------+
                  |   HUMAN REVIEW GATE     |
                  |  (file 05 checklist)    |
                  +-------------------------+
                               |
                               v
                      Outreach goes out
```

### Source -> Screen -> Resolve

The seven stages group under one three-stage spine. Nothing is renumbered; this is just the shape of what the stages are doing.

- **Source** (build the universe, then monitor the records): Stage 1 Parcel pull and Stage 2 Entity filter. You pull the county's full parcel roll, filter it to your asset and territory, keep the entities worth pursuing, and keep watching the records for change. On-market is only what is listed; sourcing is what exists.
- **Screen** (make the docs, run the underwriting): Stage 4 Owner enrichment, Stage 5 Comp valuation, and Stage 6 Outreach drafting, gated by Stage 7 Self-verification. Hard filters plus signal scoring narrow the universe to a shortlist, then the pipeline produces the per-candidate docs and a first-pass underwrite so you work the shortlist, not the whole county.
- **Resolve** (entity to human): Stage 3 LLC skip-trace. The deed names a shell; resolution connects public records until they triangulate on one person you can call, with a graded confidence. This is the advanced, paid edge.

Four design decisions make this work. They matter more than any individual prompt.

**1. Stages, not one mega-prompt.** Each stage is a contained job with its own prompt, its own inputs, and a defined output contract. When something goes wrong (and on messy county data, something always does), you know exactly which stage failed and can rerun just that stage.

**2. Structured handoffs.** Stages pass tables, not prose. Every stage's output is the next stage's input, in a fixed column format. This is what lets the pipeline run over hundreds of parcels without losing rows.

**3. Evidence chains for every identity claim.** When the agent says "Maple Holdings LLC is Jane Maple," it must show the chain of public records that led there. No chain, no name. This single rule kills most hallucination risk in the skip-trace stage.

**4. Verification before review, review before outreach.** The agent audits its own output (stage 7), then a human audits the agent (file 05). Two gates, in that order, every run.

---

## The seven pipeline stages

Each stage below covers four things: what it does, the prompt pattern behind it, the data it needs, and the human checkpoint. The full production prompts are in `02-prompt-suite.md`.

### Stage 1: Parcel pull

**What it does.** Pulls every parcel in the target submarket that matches the deal box: asset type, vintage range, size band. Then normalizes the mess that county data always is: inconsistent addresses, cryptic land-use codes, mixed units.

**Prompt pattern.** Constraint translation plus table normalization. The agent first restates the deal box as explicit filters (so you can see what it thinks you asked for), then applies them and flags anything ambiguous rather than dropping it. The cardinal rule: never silently drop a row.

**Data needed.** A parcel-level export for the submarket from your county assessor portal, GIS open-data download, or data provider. Owner of record and owner mailing address must be in the extract.

**Human checkpoint.** Plausibility check on the count. You know roughly how many 1980s garden-style assets sit in your submarket. If you expected several hundred qualifying parcels and got 30, a filter or a land-use code mapping is wrong. Fix it here, before the error propagates through six more stages.

### Stage 2: Entity filter

**What it does.** Splits owners of record into two buckets. Out: REITs, institutions, pension funds, national operators. Kept: LLCs, trusts, family partnerships, individuals. These are the owners who can actually say yes to an off-market conversation.

**Prompt pattern.** Rule-based classification with explicit tells, in priority order: naming patterns (fund-series numbering, REIT suffixes, national brands), mailing address signals (corporate HQ versus a local street address), and portfolio signals (one entity holding many parcels in the dataset). Anything the agent can't classify confidently gets kept and flagged, because a false drop costs a deal while a false keep costs two minutes of review.

**Data needed.** Just the stage 1 output. The owner name and mailing address fields carry most of the signal.

**Human checkpoint.** Skim the flagged "uncertain" rows. You'll recognize local names the agent can't.

### Stage 3: LLC skip-trace

**What it does.** Traces each kept LLC or trust through public records to the human behind it. Secretary of state filings name managers, members, and registered agents. Deed history shows who signed at acquisition. Mailing addresses tie entities to people. The agent works the chain.

**Prompt pattern.** Chain-of-custody reasoning. The agent must document every link: "Maple Holdings LLC, SoS filing lists manager Jane R. Maple, same mailing address as the deed signatory on the 2019 transfer, therefore Jane R. Maple." Each link cites the record it came from, and each resolution carries a confidence grade. Entities the records can't resolve are marked UNRESOLVED with a note on which record would resolve them. The prompt also forces the agent to distinguish registered agents from principals, the most common skip-trace error.

**Data needed.** Secretary of state business entity lookups and recorder/deeds history for each entity. In agent mode these are pulled automatically; in manual mode you paste the records in.

**Human checkpoint.** Review every low-confidence chain and every common-name collision flag. Never let outreach proceed on an undocumented chain.

### Stage 4: Owner enrichment

**What it does.** Turns resolved names into reachable people: verified email and direct cell for each owner, sourced from your enrichment provider.

**Prompt pattern.** Identity-match validation before contact capture. The dangerous failure here is not a missing phone number, it is the right number for the wrong John Smith. So the prompt requires a corroborating field beyond the name (mailing address, linked entity, location) before accepting a match, and carries the provider's verification flags forward verbatim. The agent is forbidden from upgrading "unverified" to "verified."

**Data needed.** Enrichment results from your skip-trace or contact data provider for each resolved person.

**Human checkpoint.** Scan contact confidence scores and conflict flags. Anything where provider data contradicts the public record gets resolved by a human before stage 6.

### Stage 5: Comp valuation

**What it does.** Values each target against live sale and lease comps with line-by-line adjustments, using your valuation template and anchored on your trusted comps. For apartments, the production system runs comps autonomously, pulling and selecting them itself. For other asset types, lean on the trusted comps you provided plus comps you supply.

**Prompt pattern.** An appraisal-style adjustment grid, made fully explicit. For each target the agent selects 3 to 6 comps and explains both selections and rejections, then builds a line-item adjustment grid per comp (location, size, vintage and condition, timing, deal terms), each line with direction, magnitude, and a one-sentence rationale. The grid reconciles to a low/base/high range weighted by comp quality. Two hard rules: show the arithmetic, and never invent rents, NOI, or condition. Missing inputs become stated assumptions, marked as such.

**Data needed.** Your valuation template, your trusted comps, and recent market comps for the submarket from your comps source.

**Human checkpoint.** Read the full adjustment grid for your top targets. The question is not "is the number right" but "is this how I would have reasoned." If the adjustments track your logic, the screening values downstream are trustworthy.

### Stage 6: Outreach drafting

**What it does.** Drafts a personalized owner letter, email, and call script for every target property. Personalization comes only from facts the pipeline established: hold period from deed history, the asset's specifics, submarket activity. Templates with merge slots are in `03-outreach-templates.md`.

**Prompt pattern.** Fact-grounded personalization with an authenticity test: every piece must read like it could only have been written about this property and this owner. No invented familiarity, no broker-speak the owner has read fifty times, and no specific dollar figure in the first touch (the number is the reason they take your call). Emails must carry real sender identity and a working opt-out line.

**Data needed.** The ranked targets with owner and valuation context, plus a short sender profile: who you are, your angle, how you sign off.

**Human checkpoint.** Read every piece before it goes out. Edit for your voice. This is the one stage where "good enough" is not good enough, because this is the part the owner actually sees.

### Stage 7: Self-verification

**What it does.** The agent audits its own work before you see it. It re-checks contact fields against sources, re-runs valuation arithmetic line by line, re-walks every evidence chain, and hunts for the three classic failures: identity drift (right entity, wrong human), stale data (the owner who sold last quarter), and arithmetic slips in adjustment grids. Then it assembles the final ranked list.

**Prompt pattern.** Adversarial self-audit. The verification prompt explicitly instructs the agent to treat the earlier stages as untrusted and to find errors, not confirm work. Every correction is logged with both the before and after. Targets that fail any check land in a NEEDS REVIEW section rather than being silently dropped or silently kept. Ranking weighs deal-box fit, owner-profile match, and confidence.

**Data needed.** The full pipeline output plus the original source data, so claims can be checked against ground truth rather than against the pipeline's own intermediate steps.

**Human checkpoint.** This stage's output is the human checkpoint: the ranked list, the verification log, and the NEEDS REVIEW section together are your review packet. Work through `05-verification-checklist.md` before any outreach.

---

## Running it with Claude

There are two ways to run this, and you should be clear-eyed about the difference.

### Conversation mode (no code, start today)

Open a Claude project, load your deal box, valuation template, and trusted comps as project files, and run the seven prompts from `02-prompt-suite.md` in order. You pull the data at each stage (assessor export, SoS lookups, enrichment results) and paste it in; Claude does the screening, tracing, matching, valuation, drafting, and verification.

Practical notes for conversation mode:

- **Batch your parcels.** Feed stage 1 and 2 in chunks of roughly 50 to 100 rows so nothing falls out of a long table. Merge the outputs.
- **Save every stage output as a file** and feed it to the next stage explicitly. The structured handoff is what keeps the pipeline honest.
- **Expect an afternoon, not 38 minutes.** The manual data-pulling between stages is your bottleneck. You will still finish a submarket in a day that would have taken an analyst weeks.

### Agent mode (what production looks like)

The production version of the sourcing agent is a Claude-based agent with tool access: it queries parcel data, entity records, and the enrichment provider itself, passes structured outputs between stages automatically, and writes its results to files. The same seven prompts become the stage instructions inside an agentic loop (Claude Code, or the Claude API with tools). The custom architecture work is mostly plumbing: data source connectors, an orchestration layer that runs stages in order, and storage for intermediate outputs.

This is the configuration behind the 38-minute number. If you have an engineer, the prompt suite in this pack is the specification; the stages, contracts, and rules transfer directly.

### Model tier

This workflow runs best on **Claude Fable 5**, released June 9, 2026. The reason is the shape of the work: long multi-stage runs over large tables, hundreds of rows where every row matters, and instruction-dense prompts whose rules have to hold from row 1 to row 400. Fable 5's gains in long-horizon agentic work and instruction adherence are exactly what this pipeline leans on. On smaller models you will see rules quietly degrade mid-table, which in this workflow means dropped parcels and unflagged uncertainty, the expensive kind of error.

---

## What the real runs looked like

Two data points, both from actual runs of the production system.

**Run one: sourcing.** One submarket, one deal box. The agent pulled every matching parcel, filtered to private owners, traced the LLCs, enriched contacts, and delivered 200+ off-market owners, ranked, in 38 minutes. The equivalent list, built by an analyst working assessor exports and SoS lookups by hand, is 2 to 3 weeks of work.

**Run two: valuation.** From that ranked list, BOV and memo drafts with comp maps for the top 5 targets in another 15 minutes, each with the full line-by-line adjustment grid behind the number.

Two qualifiers we want on the record. First, these are agent-mode numbers with the data connectors already built; your first conversation-mode run will be slower, and that is fine. Second, autonomous comp-running is proven on apartments. On other asset types the valuation stage leans on the trusted comps you provide, which is why the deal box asks for them.

---

## Limits and verification

Knowing where this breaks is half the value of this guide.

- **Skip-trace confidence varies.** Common names, stale secretary of state filings, and registered-agent shells all degrade the chain. The evidence-chain rule means the agent tells you when a resolution is weak instead of bluffing, but weak chains still need a human.
- **Contact data decays.** "Verified" means verified by your provider at pull time, not guaranteed deliverable. Expect some bounces and wrong numbers; the verification checklist includes a contact spot-check for exactly this reason.
- **The valuations are screening-grade.** A line-by-line adjusted BOV is a strong basis for deciding who to call first. It is not an appraisal and it is not underwriting. Treat the range as a conversation tool.
- **County data is chaos.** Land-use codes differ by county, fields go missing, formats drift. Stage 1's flag-don't-drop rule absorbs most of it, but budget review time for flagged rows on your first run in any new county.
- **The human gate is not optional.** Every claim in the outreach traces back to a record; your review confirms that before an owner ever reads it. Skipping the checklist to save twenty minutes is how a wrong-owner letter goes out with your name on it.
- **Compliance is yours.** Scrub call lists against the National Do Not Call Registry and applicable state registries before dialing. Emails need truthful sender identity and a functioning opt-out (CAN-SPAM). Some states add their own telemarketing and solicitation rules. None of this pack is legal advice; when in doubt, ask your counsel.

---

## What's in the rest of the pack

| File | What it is |
|---|---|
| `01-deal-box-template.md` | The fillable deal box: asset type, vintage, deal size, submarket, owner profile, return target, hard no's, sponsor fit. |
| `02-prompt-suite.md` | The seven production prompts, with input slots and output contracts. |
| `03-outreach-templates.md` | Owner letter, email, and call script with property-specific merge slots. |
| `04-data-source-map.md` | What data feeds each stage, by source category. |
| `05-verification-checklist.md` | The human QA pass that stands between the ranked list and the mailbox. |

Start with the deal box. Everything downstream is only as good as it.

---

*Built by NextAutomation. We design and deploy AI agents for real estate investors, brokers, and developers. nextautomation.us*
