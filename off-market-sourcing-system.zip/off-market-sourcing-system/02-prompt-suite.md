# The 7-Prompt Agent Suite

Run in order. Each prompt declares its INPUT slots and its OUTPUT CONTRACT. Feed
each stage's output table to the next stage unchanged. Conversation mode: paste the
data yourself. Agent mode: these become the stage instructions in your harness.

---

## Stage 1: Parcel pull

```
You are screening parcels for a CRE acquisition mandate.

DEAL BOX:
{paste 01-deal-box-template.md, completed}

PARCEL DATA:
{paste the county assessor / GIS / data-provider export for the submarket}

First, restate the deal box as explicit filters (asset type codes, vintage range,
size band) so I can correct your interpretation before you apply it.
Then apply the filters to every row.

Rules:
- NEVER silently drop a row. Rows that fail filters go to an EXCLUDED count by
  reason. Rows you cannot classify go to FLAGGED with a one-line reason.
- Normalize addresses and units as you go.

OUTPUT CONTRACT, one table, one row per kept parcel:
| parcel_id | address | asset_type | year_built | size | owner_of_record | owner_mailing_address | flag |
Followed by: kept / excluded / flagged counts.
```

## Stage 2: Entity filter

```
Classify each owner of record from the Stage 1 table.

INPUT: {Stage 1 table}

Buckets, in priority order of tells:
- DROP: REITs, institutions, pension funds, national operators. Tells: REIT/fund
  suffixes, fund-series numbering, corporate HQ mailing addresses, one entity
  holding many parcels in this dataset.
- KEEP: LLCs, trusts, family partnerships, individuals.
- UNCERTAIN: cannot classify confidently -> KEEP and flag. A false drop costs a
  deal; a false keep costs two minutes of review.

OUTPUT CONTRACT:
| parcel_id | owner_of_record | classification | tells_used | flag |
Followed by counts per bucket. List every UNCERTAIN row for human review.
```

## Stage 3: LLC skip-trace

```
Trace each KEPT entity from Stage 2 to the human decision-maker.

INPUT: {Stage 2 KEEP rows} + {secretary of state lookups, recorder/deeds history
per entity, pasted in conversation mode, tool-fetched in agent mode}

THE EVIDENCE-CHAIN RULE: a name is only asserted with a documented chain, e.g.
"Maple Holdings LLC -> SoS filing lists manager Jane R. Maple -> same mailing
address as deed signatory on the 2019 transfer -> Jane R. Maple." Every link
cites its record. No chain, no name.

Rules:
- Distinguish registered agents from principals. An agent is NOT an owner.
- Grade each resolution HIGH / MEDIUM / LOW confidence.
- Unresolvable entities -> UNRESOLVED, with a note on which record would resolve it.
- Flag common-name collisions explicitly.

OUTPUT CONTRACT:
| parcel_id | entity | resolved_human | evidence_chain | confidence | flag |
```

## Stage 4: Owner enrichment

```
Validate contact enrichment for each resolved human from Stage 3.

INPUT: {Stage 3 table} + {enrichment/skip-trace provider results}

IDENTITY-MATCH RULE: accept a contact match only with a corroborating field
beyond the name (mailing address, linked entity, geography). The dangerous
failure is the right number for the wrong John Smith.

Rules:
- Carry the provider's verification flags forward VERBATIM. Never upgrade
  "unverified" to "verified".
- Provider data contradicting the public record -> CONFLICT flag for human
  resolution.

OUTPUT CONTRACT:
| parcel_id | owner | email | email_status | cell | cell_status | match_corroboration | flag |
```

## Stage 5: Comp valuation

```
Value each target using MY valuation method.

INPUT: {Stage 4 table} + {my valuation template} + {my 3-5 trusted comps} +
{market comps for the submarket}

For each target:
1. Select 3-6 comps. State why each was selected AND why near-misses were rejected.
2. Build a line-item adjustment grid per comp: location, size, vintage/condition,
   timing, deal terms, each line with direction, magnitude, and a one-sentence
   rationale.
3. Reconcile to a LOW / BASE / HIGH range weighted by comp quality.

Hard rules: show the arithmetic. NEVER invent rents, NOI, or condition. Missing
inputs become stated assumptions, marked ASSUMPTION. Anchor adjustment logic to
my trusted comps.

OUTPUT CONTRACT per target: comp selection table, adjustment grid, value range,
assumptions list. Plus a summary table: | parcel_id | low | base | high | confidence |
```

## Stage 6: Outreach drafting

```
Draft outreach for each ranked target.

INPUT: {Stage 5 summary + Stage 4 contacts} + SENDER PROFILE: {who you are, your
angle, how you sign off, from the deal box sponsor-fit paragraph}

For each target produce: (a) owner letter, (b) email, (c) call script.

Rules:
- Personalize ONLY from facts the pipeline established: hold period from deed
  history, the asset's specifics, submarket activity. No invented familiarity.
- The authenticity test: each piece must read like it could only have been
  written about THIS property and THIS owner.
- No specific dollar figure in the first touch.
- Emails: truthful sender identity + a working opt-out line.
- No broker-speak clichés ("I have a buyer ready", "all cash, quick close").

OUTPUT CONTRACT: per target, the three pieces with merge slots filled, ready for
human edit (not send).
```

## Stage 7: Self-verification

```
You are now the AUDITOR. Treat every earlier stage as untrusted work. Your job
is to find errors, not confirm them.

INPUT: {all stage outputs} + {original source data}

Checks:
1. Re-verify each contact field against its source.
2. Re-run valuation arithmetic line by line.
3. Re-walk every evidence chain; downgrade any link that does not hold.
4. Hunt the three classic failures: identity drift (right entity, wrong human),
   stale data (owner already sold), arithmetic slips in adjustment grids.

Rules: log every correction with before/after. Targets failing ANY check go to
NEEDS REVIEW, never silently dropped, never silently kept.

OUTPUT CONTRACT:
1. RANKED LIST: | rank | parcel | owner | contacts | value range | fit score | confidence |
   (rank = deal-box fit x owner-profile match x confidence)
2. VERIFICATION LOG (all corrections)
3. NEEDS REVIEW section
Hand this packet to the human gate (05-verification-checklist.md).
```
