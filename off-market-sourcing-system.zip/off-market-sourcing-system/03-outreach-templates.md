# Outreach Templates

Three pieces per target, drafted by Stage 6, edited by you. Merge slots in
{braces}. The rule behind all three: every personalized line traces to a record
the pipeline established. If you can't point to the record, cut the line.

---

## Owner letter (print, signed, mailed)

```
{owner_first_name} {owner_last_name}
{owner_mailing_address}

Dear {owner_first_name},

I'm writing about {property_address}, the {asset_descriptor} you've owned since
{acquisition_year}. I'll keep this short.

My firm acquires {asset_type} in {submarket_name}, and your property fits what
we close on. This isn't a blast letter: we looked at {specific_property_fact,
e.g. "the 48 units and the 2019 roof work visible in the permit record"} before
writing to you.

If you've ever wondered what the building would trade for in today's market,
I'd welcome a 15-minute conversation. No listing, no obligation, and I'll share
our read on value either way.

{sender_signoff}
{sender_name}
{sender_firm} · {sender_phone} · {sender_email}
```

## Email (first touch)

```
Subject: {property_address}, owner question

{owner_first_name},

Quick note about {property_address}. We acquire {asset_type} in
{submarket_name} and your building fits our mandate.

You've held it since {acquisition_year}, so you know what it is better than
anyone. If a conversation about today's value is ever useful, I'm easy to
reach, and happy to share our underwriting view either way.

{sender_name}
{sender_firm} · {sender_phone}

If you'd rather not hear from me again, reply "no thanks" and that's that.
```

## Call script

```
OPEN
"Hi {owner_first_name}, this is {sender_name} with {sender_firm}. Do you have a
quick minute? I'm calling about {property_address}."

WHY THEM (one breath, facts only)
"We acquire {asset_type} in {submarket_name}. Your property came up because
{specific_fact, e.g. 'you've held it since 2011 and it's exactly the vintage we
buy'}. This isn't a listing pitch."

THE ASK
"I'm not going to throw a number at you on a cold call. If you're open to it,
I'd like 15 minutes to share how we'd look at the building and hear whether a
sale is even interesting this year."

OBJECTION, "Not for sale."
"Completely fair, most owners we end up working with said the same at first.
Would it be useful to have our view on value anyway, no strings?"

OBJECTION, "Send me something."
"Will do. I'll email a short note on our mandate today, no attachment spam.
What's the best email? I have {email_on_file}."

CLOSE
"Appreciate the time, {owner_first_name}. You'll have my details either way.
If timing changes in a year, the offer of a conversation stands."
```

---

**Compliance reminders (non-negotiable):** scrub against the National Do Not
Call Registry and state registries before dialing. Emails carry truthful sender
identity and the opt-out line. First touch never includes a dollar figure.
