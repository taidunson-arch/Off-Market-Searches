# Worked Example: one county, end to end

**County: Mecklenburg County, North Carolina (Charlotte).**
Picked because all three records this method depends on are free and online there,
which means you can re-run every step below yourself without buying anything.

> ## Read this before you read the tables
>
> **The sources, the portals, the search paths and the record types below are real
> and checkable.** Everything else is illustrative: the parcel numbers, entity names,
> owner names, addresses and dates, AND every count, total and ratio in this file.
> None of them is output from a real Mecklenburg run.
>
> Two reasons, both deliberate. Publishing a real private individual's home address
> and phone number in a free download is not something we are willing to do. And the
> real county runs we operate are paid client work under confidentiality. So the
> method here is exactly what we run, and the rows are stand-ins that behave the way
> real rows behave, including the ones that fail.
>
> Short version: the sources are real, the numbers are not. The counts are sized to
> behave the way real counts behave, including the ones that fail, so you know what
> shape to expect. Do not quote them as our results.

---

## The three free sources

| Stage | What you need | Where it is, in this county |
|---|---|---|
| 1 Parcel pull | Parcel-level export with land use, year built, size, owner of record, owner mailing address | **POLARIS 3G**, `polaris3g.mecklenburgcountync.gov`, the county's public parcel viewer. Bulk parcel layers come from the county's open GIS data. |
| 3 Skip-trace, registry side | Entity filings, status, registered agent, company officials | **NC Secretary of State business registration search**, `sosnc.gov`. Free. Searchable by company, by registered agent, and **by company official**, which is the reverse lookup most states do not give you. |
| 3 Skip-trace, deed side | Deed history, grantee mailing addresses, deeds of trust | **Mecklenburg County Register of Deeds**, `deeds.mecknc.gov`. Records from March 1990 to today are in the online index with images; 1763 to February 1990 sit in a separate historical system. |

Stages 1 to 3 cost nothing here. Stage 4, contact enrichment, is the first step that
needs a source you bring. That split is the honest shape of this work: the trace is
free, the phone number is not.

## The deal box used for this run

```
Asset type:      light industrial / small-bay flex, 15,000 to 60,000 sf
Vintage:         1975 to 2005
Deal size:       $2M to $12M
Territory:       Mecklenburg County, NC
Owner profile:   keep LLCs, trusts, family partnerships, long holds
                 drop REITs, funds, national operators
Signals up:      out-of-state mailing address, hold over 10 years, low basis
Hard no's:       ground lease, known environmental flag
```

---

## Stage 1: Parcel pull

The export column that does the work is the land-use / property-use code. **Its
legend is county-specific.** Pull Mecklenburg's legend first and paste it into the
prompt with the data, or the agent will guess which codes mean flex industrial and
guess wrong. This is the single most common way a run silently loses half its
universe.

Illustrative counts, shaped the way a real screen behaves:

```
Rows in export ................................ 4,812   (all industrial-coded parcels)
Excluded, land use out of scope ............... 3,104   (warehouse distribution over 60k sf,
                                                         heavy manufacturing, land only)
Excluded, vintage outside 1975-2005 ..............621
Excluded, size outside 15k-60k sf ................725
Kept ............................................ 362
  of which flagged, code not in the legend ......41   <- kept for review, never dropped
```

That flagged 41 is the point of the stage. In a real county a handful of them are flex
buildings coded under a retired code the legend no longer carries. A pipeline that drops
unclassifiable rows loses those buildings and never tells you.

| parcel_id | address | asset_type | year_built | size_sf | owner_of_record | owner_mailing | flag |
|---|---|---|---|---|---|---|---|
| *(illustrative)* 111-222-33 | 4400 Rozzelles Ferry Rd | flex industrial | 1986 | 38,400 | Rozzelles Flex Holdings LLC | PO Box, Naples FL | out-of-state |
| *(illustrative)* 111-222-34 | 5210 Wilkinson Blvd | small-bay | 1992 | 22,100 | Catawba Bay Partners LP | Charlotte NC | none |
| *(illustrative)* 111-222-35 | 3018 Nevada Blvd | flex industrial | 1979 | 51,000 | (national operator) | Chicago IL | drop at stage 2 |

## Stage 2: Entity filter

```
Kept from stage 1 ............................... 362
DROP, institutional tells ....................... 118   (fund-series numbering, one entity
                                                         on 20+ parcels, corporate HQ mailing)
KEEP, LLC / trust / LP / individual ............. 227
UNCERTAIN, kept and flagged ...................... 17
```

The tell that earns its keep: **one entity holding many parcels inside this same
dataset**. It separates a national operator from a local family that happens to use
a formal-sounding name, and it needs no outside data at all.

## Stage 3: Skip-trace, the stage that decides the run

Take one KEEP row and walk it.

**Illustrative trace, Rozzelles Flex Holdings LLC:**

```
1. NC SoS, company search "Rozzelles Flex Holdings LLC"
   -> status Current-Active, SOSID on file
   -> registered agent: a corporate-services company in Raleigh
   -> company officials: one manager listed, "R. T. Alden", address in Naples, FL

   The registered agent is a service address. It is not an owner. This is where a
   careless run stops and reports a law firm as the buyer's counterparty.

2. Register of Deeds, grantee search on the entity
   -> 2011 general warranty deed, grantee Rozzelles Flex Holdings LLC
   -> grantee mailing address on the instrument matches the Naples address the
     registry lists for R. T. Alden
   -> two records now agree on one human

3. NC SoS, search BY COMPANY OFFICIAL, "R. T. Alden"
   -> three further active LLCs, all with the same Naples mailing address

4. Cross-check those three entity names back against the stage 1 parcel table
   -> two of them hold parcels inside this same county export

Result: one human, four assets in the county, fourteen-year hold on the anchor
parcel, out-of-state. Confidence HIGH, two independent records, principal not agent.
```

Step 3 is the one people skip. Searching the registry **by official** rather than by
company turns one parcel into a portfolio, and a portfolio owner is a materially
better call than a single-asset owner.

Illustrative trace rate:

```
Entities in ..................................... 227
HIGH   (two or more agreeing records) ........... 96
MEDIUM (one strong record) ...................... 58
LOW    (inference, named record would confirm) .. 31
UNRESOLVED ...................................... 42
```

Roughly one in five unresolved is the normal, honest shape, and most fail for one
boring reason: the deed that names the human predates March 1990 and is only in
the historical system, index without a searchable image. The output says so per row
rather than reporting a confident guess.

## Stage 4: Enrichment

Nothing here comes from the county. You bring a contact source, and the agent's job
is to refuse the matches that do not corroborate.

| owner | email_status | cell_status | corroboration | flag |
|---|---|---|---|---|
| *(illustrative)* R. T. Alden | provider-verified | provider-verified | Naples mailing address matches deed grantee | none |
| *(illustrative)* J. Smith | provider-verified | unverified | name only | **CONFLICT, name-only match, do not call** |

The second row is the whole point of the stage. A verified phone number for the
wrong J. Smith looks identical to a good record until you dial it.

## Stage 5: Valuation

Abbreviated, one target. The rejections are what show the work.

```
Selected:  3 flex sales inside 2.5 miles, 2024 to 2026, 24k to 44k sf
Rejected:  a 2023 sale at 61k sf         -> above the size band, different buyer pool
           a 2025 sale 6 miles east      -> different submarket, rail-served
           a 2026 sale with seller financing -> deal terms not comparable

Adjustments, comp A:  size +4%, vintage -6%, timing +3%, location 0
                      -> indicated $/sf, arithmetic shown per line

Reconciled:  LOW / BASE / HIGH, weighted to comp A on proximity and size
ASSUMPTIONS: clear height not in the county record, assumed at the submarket norm.
             Labelled. A site visit replaces it.
```

Confidence is LOW whenever fewer than three comps survive, and it says so instead of
producing a tidy number from a thin set.

## Stage 6: Outreach

One personalized fact, sourced. No dollar figure.

> Your building on Rozzelles Ferry has been in the same ownership since 2011, which
> is longer than almost anything that has traded in that pocket. I buy small-bay flex
> in Mecklenburg and I closed two this year. If you ever consider a sale, would you
> want a conversation before it goes to market?

Every claim traces: the hold period to the 2011 deed, the asset specifics to the
parcel record, the sponsor proof to the deal box.

## Stage 7: Self-audit, and what it caught

The auditor re-walks everything. In this example it catches:

```
- 3 owners had sold since the export date. Caught by re-checking the deed index.
  Removed from the list.
- 1 evidence chain downgraded HIGH -> MEDIUM. The "second record" turned out to be
  the same filing surfaced twice through two search paths, which is one record.
- 2 adjustment grids had arithmetic that did not reproduce. Corrected, both moved
  the base by under 3%.
- 6 targets moved to NEEDS REVIEW rather than being dropped.
```

That second one is the failure worth naming. Two search paths returning the same
underlying document is the most convincing false corroboration in this work, and it
is invisible unless something goes back and checks the instrument numbers.

## What came out

```
4,812 parcels in
  362 matched the deal box
  227 survived the entity filter
   96 traced to a named human at HIGH confidence
   61 cleared enrichment, valuation and the audit
   61 went to the human gate in 05-verification-checklist.md
```

Roughly one in eighty parcels becomes a call worth making. That order of magnitude is
what this work looks like. Anyone promising you a much higher one is either working a
looser mandate or not checking their chains.

## Re-run this yourself

1. Open POLARIS 3G, find any industrial parcel, note the owner of record and the
   owner mailing address.
2. Search that entity on `sosnc.gov`. Note the registered agent and the company
   officials, and notice which one is a service address.
3. Search the Register of Deeds by that entity as grantee. Compare the mailing
   address on the instrument to the registry's official address.
4. Search `sosnc.gov` again, this time **by company official**, using the name you
   just found.

Four searches, no cost, and you will have done stage 3 by hand on one parcel. The
system in this pack is that, held to a county.
