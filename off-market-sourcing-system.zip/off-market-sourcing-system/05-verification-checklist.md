# Human Verification Checklist

The gate between the agent's ranked list and the mailbox. Twenty minutes that
keep a wrong-owner letter from going out with your name on it. Work top to
bottom; do not skip.

## 1. Identity (per top-10 target)

- [ ] Evidence chain reads cleanly: every link cites a record
- [ ] The named human is a principal, NOT a registered agent
- [ ] Common-name collisions resolved (right John Smith)
- [ ] No UNRESOLVED or LOW-confidence entity in your outreach batch

## 2. Contacts (spot-check 5 minimum)

- [ ] Email verification flag is provider-verified, not agent-assumed
- [ ] Cell matches the person, corroborated by a second field
- [ ] CONFLICT flags (provider vs public record) resolved by you
- [ ] Call list scrubbed against the National DNC Registry + your state registry

## 3. Valuation (read the full grid for top 5)

- [ ] Comp selections make sense for this asset; rejections justified
- [ ] Adjustment directions match your market read
- [ ] Arithmetic checks (Stage 7 re-ran it; trust but verify one)
- [ ] Every ASSUMPTION is acceptable or replaced with real data
- [ ] You'd defend the BASE number on a call with the owner

## 4. Outreach (read every piece going out)

- [ ] Each personalized fact traces to a pipeline record
- [ ] No dollar figure in any first touch
- [ ] Sender identity truthful; email opt-out line present and working
- [ ] It sounds like you after your edit, not like a template

## 5. The NEEDS REVIEW section

- [ ] Every flagged target dispositioned: fixed, deferred, or dropped, none ignored

## 6. Log it

- [ ] Save the verification log with the run date
- [ ] Note bounce/wrong-number rates after the first outreach wave; they tell
      you whether your enrichment source is good enough for this market

Pass all six sections and the list is ready. Anything failing goes back to its
stage, not into the mail.
