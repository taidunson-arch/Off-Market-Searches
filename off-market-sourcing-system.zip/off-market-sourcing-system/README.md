# The Off-Market Sourcing System

**A Claude agent that reads the county public records you hand it and returns the owners worth calling.**
By NextAutomation | nextautomation.us

---

## What this is

Anyone can pull an absentee-owner list. Almost nobody gets from the LLC on the deed
to the human behind it, and that gap is where most off-market outreach dies. This
pack is the system that closes it: a seven-stage pipeline that screens parcels
against your mandate, classifies owners, traces each entity to a named principal
with a documented evidence chain, values the asset, and drafts outreach that could
only have been written about that property.

It ships two ways to run. The `agents/` folder holds installable agent files you
drop into Claude and run. The numbered docs hold the method behind them, so you can
read what each stage is doing and change it when your county behaves differently.

> One honest note up front. This pack teaches the trace and gives you the agents that
> run it. It does **not** hand you a contact list. Every ranked target passes a human
> review gate before a letter goes out, and that gate is part of the design, not an
> apology for it.

## The Method: Source -> Screen -> Resolve

Everything in this pack sits on one spine. Three stages, in order.

**Source** builds the universe, then keeps watching it. On-market is only what is listed for sale; sourcing is what actually exists. You pull the county's full parcel roll, filter it to your asset and territory, and then keep monitoring the records for change. You are fishing the whole lake, not the one stocked pond every other buyer is crowded around. This stage is owned by the **sourcing-agent**.

**Screen** makes the docs and runs the underwriting. A single county can hold thousands of flex parcels and you cannot call thousands. Screening makes two cuts: hard filters (your buy box - size, price, exclusions), then signal scoring (absentee, long hold, tax delinquency, a maturing loan, estate or trust ownership) to rank who is likely to sell. It produces the per-candidate docs and a first-pass underwrite so you work the shortlist, not the universe. This stage is owned by the **valuation-analyst** and the deal-doc outputs.

**Resolve** turns the entity into a human. The deed names a shell company, not a person. Resolution connects the dots across public records - who signs for the LLC, where its mail goes, what else they own - until they triangulate on one person you can actually call, with a graded confidence. This is the advanced, paid edge of the system. This stage is owned by the **skiptrace-analyst**.

## What's in the pack

```
off-market-sourcing-system/
+-- README.md                       <- you are here
+-- 00-START-HERE-buy-box-setup.md   <- run this first: builds your buy box + feasibility read
+-- worked-example.md               <- the method run end to end on one county
+-- agents/
|   +-- sourcing-agent.md            <- the lead: runs all seven stages, owns the run
|   +-- skiptrace-analyst.md         <- stage 3 specialist: entity to named human
|   +-- valuation-analyst.md         <- stage 5 specialist: comps, adjustments, range
|   \-- outreach-writer.md           <- stage 6 specialist: letter, email, call script
+-- 00-implementation-guide.md      <- the full architecture, stage by stage
+-- 01-deal-box-template.md         <- your mandate, encoded once
+-- 02-prompt-suite.md              <- the seven raw stage prompts
+-- 03-outreach-templates.md        <- letter, email and call templates
+-- 04-data-source-map.md           <- what feeds each stage, by source category
+-- 05-verification-checklist.md    <- the twenty-minute human gate
\-- 06-off-market-operating-system.pdf   <- the full method, one branded PDF
```

Run `00-START-HERE-buy-box-setup.md` first: it interviews you, builds your buy box,
and gives a feasibility read on whether your counties are sourceable from public
records. Then read `worked-example.md` to see the shape of a full run, or
`00-implementation-guide.md` for the architecture.

## How to run it (no code)

You do not need to be a developer. Pick the tool you already use.

**Claude (Project), recommended, 10 minutes**

1. Create a new Project in Claude.
2. Drag every `.md` file in this pack into the Project knowledge, including the
   `agents/` folder.
3. Open `agents/sourcing-agent.md`, copy the fenced block, and paste it into the
   Project instructions. Fill the `{...}` slots with your deal box.
4. Start a chat with your first county's parcel export attached. The agent restates
   your mandate as filters and waits for you to confirm before it runs anything.

**Claude Code (Skill or subagent), dev environment**

1. Drop this folder into your project.
2. Point a skill, a subagent definition, or your `CLAUDE.md` at
   `agents/sourcing-agent.md` as the entry instruction.
3. The three specialists in `agents/` are written to be dispatched as subagents. The
   lead agent hands each one a stage's input table and merges what comes back, so
   stage 3 and stage 5 can run on different targets at the same time.
4. Keep source extracts on disk. Stage 7 audits against the original files, not
   against the pipeline's own notes.

**ChatGPT (Project or custom GPT)**

1. Upload the pack files as Project files or custom-GPT knowledge.
2. Paste the `agents/sourcing-agent.md` block as the system instruction.
3. Run one stage per message and paste each stage's output table into the next. The
   output contracts exist so nothing is lost between stages.

**Codex / any coding agent**

1. Put the folder in the repo root.
2. Reference `agents/sourcing-agent.md` from `AGENTS.md` (or your agent's config) as
   the entry instruction, and the three specialists as its tools.
3. Give it read access to your saved source extracts and a place to write the run log.

## The one input you must fill

Everything reads from your **deal box**: asset type, vintage, deal size, target
submarkets, owner profile, hard no's, sponsor fit. `01-deal-box-template.md` is the
blank template; `00-START-HERE-buy-box-setup.md` is the agent that interviews you and
fills it (recommended, especially for small-bay flex, light-industrial, and IOS). A
sloppy deal box produces a long list of owners you do not want, which is worse than
no list. Spend twenty minutes on it.

## The shape of a run

```
   YOUR DEAL BOX  +  county parcel export
                         |
                         v
        1  PARCEL PULL     screen to the mandate, count every exclusion
        2  ENTITY FILTER   institutions out, LLCs and trusts and families in
                         |
                         v
        3  SKIP-TRACE      entity -> named human, evidence chain per link
                         |           (agents/skiptrace-analyst.md)
                         v
        4  ENRICHMENT      contacts, provider flags carried forward verbatim
        5  VALUATION       comps, adjustment grid, low/base/high
                         |           (agents/valuation-analyst.md)
                         v
        6  OUTREACH        letter, email, call script per target
                         |           (agents/outreach-writer.md)
                         v
        7  SELF-AUDIT      auditor re-walks every chain and every number
                         |
                         v
              RANKED LIST + verification log + NEEDS REVIEW
                         |
                         v
              HUMAN GATE (05-verification-checklist.md)
                         |
                         v
                 your prioritized call list
```

## What it will not do

- It will not invent an owner. No documented chain, no name.
- It will not upgrade a provider's "unverified" contact to "verified".
- It will not put a dollar figure in a first touch.
- It will not give you contact data. Stages 1 through 3 run on free county and state
  portals. Stage 4 needs an enrichment source you bring, and the pack tells you what
  category of source to look for rather than selling you one.

## Where to go next

The team version of this system runs many counties at once: one orchestrator, four
tuned scouts, one merged deal table.
**nextautomation.us/resources/offmarket-sourcing-team**
