# Data Source Map

What feeds each stage, by source CATEGORY. We deliberately don't name vendors:
coverage and quality vary by market, and the prompts treat every source as a
pluggable input. Use what's strong in your county.

| Stage | Needs | Source category | Notes |
|---|---|---|---|
| 1 Parcel pull | Parcel-level export: address, asset/land-use code, year built, size, owner of record, owner mailing address | County assessor portal, county/city GIS open-data, or a commercial parcel data provider | Land-use codes differ per county, so keep the code legend handy for the prompt |
| 2 Entity filter | Nothing new | Stage 1 output | Owner name + mailing address carry the signal |
| 3 LLC skip-trace | Entity filings, deed history | Secretary of state business-entity search (free in most states), county recorder/register of deeds | SoS data staleness is the #1 chain-breaker; deeds fill the gaps |
| 4 Owner enrichment | Verified email + cell per person | Contact enrichment / skip-trace provider (the category includes both CRE-specific and general B2B providers) | Demand verification flags in the output; carry them verbatim |
| 5 Comp valuation | Recent sale + lease comps | Your comps source: brokerage research, a comps platform, county transfer records | Your 3-5 trusted comps anchor everything; for multifamily the agent can assemble the set itself |
| 6 Outreach | Sender profile | You | The sponsor-fit paragraph from the deal box |
| 7 Verification | All original source data | Everything above | The auditor checks claims against ground truth, not against the pipeline's own notes |

## Practical tips

- **Start where data is free**: assessor portal + SoS search + recorder gets you
  through stages 1-3 in most counties without spending a dollar.
- **One submarket at a time.** The pipeline's accuracy comes from the deal box
  being specific; resist running a whole metro on day one.
- **Save raw extracts.** Stage 7 audits against ground truth, so keep every source
  file you fed in.
