import * as XLSX from 'xlsx';
import { affordableHousingData } from '../data/affordableHousingData';
import { commercialLoanMaturities } from '../data/commercialLoanData';
import type { AffordableHousingProperty } from '../data/affordableHousingData';
import type { CommercialLoanMaturity } from '../data/commercialLoanData';

const fmtCurrency = (v: number) => v >= 1000000 ? `$${(v / 1000000).toFixed(2)}M` : `$${(v / 1000).toFixed(0)}K`;
const fmtDate = (d: string) => new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });

// Auto-size columns based on content
function autoSizeColumns(ws: XLSX.WorkSheet, maxWidth = 40) {
  const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
  const colWidths: XLSX.ColInfo[] = [];
  for (let c = range.s.c; c <= range.e.c; c++) {
    let maxLen = 10;
    for (let r = range.s.r; r <= range.e.r; r++) {
      const addr = XLSX.utils.encode_cell({ r, c });
      const cell = ws[addr];
      if (cell && cell.v) {
        maxLen = Math.max(maxLen, Math.min(String(cell.v).length, maxWidth));
      }
    }
    colWidths.push({ wch: maxLen + 2 });
  }
  ws['!cols'] = colWidths;
}

// Freeze top row (header)
function freezeHeader(ws: XLSX.WorkSheet) {
  if (!ws['!views']) ws['!views'] = [];
  ws['!views'].push({ state: 'frozen' as const, ySplit: 1 });
}

export interface ExportOptions {
  filteredAH?: AffordableHousingProperty[];
  filteredCL?: CommercialLoanMaturity[];
  includeSummary?: boolean;
  includeAnalytics?: boolean;
}

export function generateExcelReport(options: ExportOptions = {}): string {
  const {
    filteredAH = affordableHousingData,
    filteredCL = commercialLoanMaturities,
    includeSummary = true,
    includeAnalytics = true,
  } = options;

  const wb = XLSX.utils.book_new();

  // ===== SHEET 1: EXECUTIVE SUMMARY =====
  if (includeSummary) {
    const totalAHUnits = filteredAH.reduce((s, p) => s + p.totalUnits, 0);
    const totalCLValue = filteredCL.reduce((s, p) => s + p.loanAmount, 0);
    const ahHighRisk = filteredAH.filter(p => p.riskLevel === 'High').length;
    const clCritical = filteredCL.filter(p => p.distressLevel === 'Critical').length;
    const ahExpiring12mo = filteredAH.filter(p => p.daysUntilExpiration <= 365 && p.daysUntilExpiration > 0).length;
    const clMaturing12mo = filteredCL.filter(p => p.daysUntilMaturity <= 365 && p.daysUntilMaturity > 0).length;

    const summaryData: any[][] = [
      ['OFF-MARKET SOURCING SYSTEM — EXECUTIVE SUMMARY'],
      [`Report Generated: ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}`],
      [''],
      ['PORTFOLIO OVERVIEW'],
      ['Metric', 'Value', 'Notes'],
      ['Affordable Housing Properties Tracked', filteredAH.length, 'Properties with land use restrictions expiring 2025-2035'],
      ['Total Affordable Units at Risk', totalAHUnits, 'Sum of all units across tracked properties'],
      ['Commercial Loans Tracked', filteredCL.length, 'Loans maturing 2026-2031'],
      ['Total Commercial Loan Value', fmtCurrency(totalCLValue), 'Aggregate principal balance'],
      [''],
      ['URGENCY METRICS'],
      ['High-Risk Affordable Properties', ahHighRisk, 'Properties with restrictions expiring soon without preservation status'],
      ['Critical-Distress Commercial Loans', clCritical, 'Loans with LTV >80%, occupancy <70%, or DSCR <1.0'],
      ['AH Expiring in Next 12 Months', ahExpiring12mo, 'Immediate action required'],
      ['CL Maturing in Next 12 Months', clMaturing12mo, 'Refinancing or acquisition window'],
      [''],
      ['FUNDING SOURCE BREAKDOWN (Affordable Housing)'],
      ['Source', 'Properties', 'Units', '% of Total'],
    ];

    const fundingBreakdown: Record<string, { count: number; units: number }> = {};
    filteredAH.forEach(p => {
      if (!fundingBreakdown[p.fundingSource]) fundingBreakdown[p.fundingSource] = { count: 0, units: 0 };
      fundingBreakdown[p.fundingSource].count++;
      fundingBreakdown[p.fundingSource].units += p.totalUnits;
    });
    Object.entries(fundingBreakdown).sort((a, b) => b[1].units - a[1].units).forEach(([source, data]) => {
      summaryData.push([source, data.count, data.units, `${((data.units / totalAHUnits) * 100).toFixed(1)}%`]);
    });

    summaryData.push(['']);
    summaryData.push(['TOP 10 COUNTIES BY UNITS AT RISK']);
    summaryData.push(['County', 'Properties', 'Units', '% of Total']);
    const countyBreakdown: Record<string, { count: number; units: number }> = {};
    filteredAH.forEach(p => {
      if (!countyBreakdown[p.county]) countyBreakdown[p.county] = { count: 0, units: 0 };
      countyBreakdown[p.county].count++;
      countyBreakdown[p.county].units += p.totalUnits;
    });
    Object.entries(countyBreakdown).sort((a, b) => b[1].units - a[1].units).slice(0, 10).forEach(([county, data]) => {
      summaryData.push([county, data.count, data.units, `${((data.units / totalAHUnits) * 100).toFixed(1)}%`]);
    });

    const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
    autoSizeColumns(wsSummary, 60);
    XLSX.utils.book_append_sheet(wb, wsSummary, 'Executive Summary');
  }

  // ===== SHEET 2: AFFORDABLE HOUSING PROPERTIES =====
  const ahHeaders = [
    'Property Name', 'Address', 'City', 'County', 'Expiration Date', 'Year',
    'Days Until Expiration', 'Total Units', 'Restricted Units',
    'Funding Source', 'OHCS Funded', 'HUD', 'USDA',
    '30% AMI', '40% AMI', '50% AMI', '60% AMI', '70% AMI', '80% AMI',
    'Risk Level', 'Investment Score', 'Preservation Status',
  ];
  const ahRows = filteredAH.map(p => [
    p.propertyName, p.address, p.city, p.county,
    fmtDate(p.expirationDate), p.expirationYear,
    p.daysUntilExpiration, p.totalUnits, p.restrictedUnits,
    p.fundingSource, p.ohcsFunded ? 'Yes' : 'No', p.hud ? 'Yes' : 'No', p.usda ? 'Yes' : 'No',
    p.ami30 || '', p.ami40 || '', p.ami50 || '', p.ami60 || '', p.ami70 || '', p.ami80 || '',
    p.riskLevel, p.investmentScore, p.preservationStatus || 'None',
  ]);
  const wsAH = XLSX.utils.aoa_to_sheet([ahHeaders, ...ahRows]);
  autoSizeColumns(wsAH);
  freezeHeader(wsAH);
  XLSX.utils.book_append_sheet(wb, wsAH, 'Affordable Housing');

  // ===== SHEET 3: COMMERCIAL LOAN MATURITIES =====
  const clHeaders = [
    'Property Name', 'Address', 'City', 'County', 'Property Type',
    'Loan Amount', 'Maturity Date', 'Year', 'Days Until Maturity',
    'Lender', 'Loan Type', 'Interest Rate',
    'Year Built', 'Sq Ft', 'Units',
    'LTV %', 'DSCR', 'Occupancy %', 'Cap Rate', 'NOI',
    'Distress Level', 'Investment Score', 'Conversion Potential',
  ];
  const clRows = filteredCL.map(p => [
    p.propertyName, p.address, p.city, p.county, p.propertyType,
    p.loanAmount, fmtDate(p.loanMaturityDate), p.maturityYear,
    p.daysUntilMaturity, p.lender, p.loanType, `${p.interestRate}%`,
    p.yearBuilt, p.sqft.toLocaleString(), p.units || 'N/A',
    `${p.ltv}%`, p.dscr.toFixed(2), `${p.occupancyRate}%`, `${p.capRate}%`, p.noi,
    p.distressLevel, p.investmentScore, p.conversionPotential,
  ]);
  const wsCL = XLSX.utils.aoa_to_sheet([clHeaders, ...clRows]);
  autoSizeColumns(wsCL);
  freezeHeader(wsCL);
  XLSX.utils.book_append_sheet(wb, wsCL, 'Commercial Loans');

  // ===== SHEET 4: COMBINED LEADS =====
  const combinedHeaders = [
    'Source', 'Property Name', 'Address', 'City', 'County',
    'Event Date', 'Year', 'Days Until Event',
    'Units / SqFt', 'Value / Score', 'Risk Level', 'Investment Score', 'Details',
  ];
  const combinedRows: any[][] = [];
  filteredAH.forEach(p => {
    combinedRows.push([
      'Affordable Housing', p.propertyName, p.address, p.city, p.county,
      fmtDate(p.expirationDate), p.expirationYear, p.daysUntilExpiration,
      `${p.totalUnits} units`, p.fundingSource, p.riskLevel, p.investmentScore,
      `${p.fundingSource} restriction expiring`,
    ]);
  });
  filteredCL.forEach(p => {
    combinedRows.push([
      'Commercial Loan', p.propertyName, p.address, p.city, p.county,
      fmtDate(p.loanMaturityDate), p.maturityYear, p.daysUntilMaturity,
      `${p.sqft.toLocaleString()} sqft`, fmtCurrency(p.loanAmount), p.distressLevel, p.investmentScore,
      `${p.propertyType} • ${p.loanType} loan maturing`,
    ]);
  });
  combinedRows.sort((a, b) => String(a[5]).localeCompare(String(b[5])));
  const wsCombined = XLSX.utils.aoa_to_sheet([combinedHeaders, ...combinedRows]);
  autoSizeColumns(wsCombined);
  freezeHeader(wsCombined);
  XLSX.utils.book_append_sheet(wb, wsCombined, 'Combined Leads');

  // ===== SHEET 5: ANALYTICS =====
  if (includeAnalytics) {
    const analyticsData: any[][] = [
      ['ANALYTICS & MARKET INTELLIGENCE'],
      [''],
      ['YEAR-BY-YEAR EXPOSURE'],
      ['Year', 'AH Properties', 'AH Units', 'CL Loans', 'CL Value'],
    ];
    const years = [...new Set([...filteredAH.map(p => p.expirationYear), ...filteredCL.map(p => p.maturityYear)])].sort();
    years.forEach(y => {
      const ahYear = filteredAH.filter(p => p.expirationYear === y);
      const clYear = filteredCL.filter(p => p.maturityYear === y);
      analyticsData.push([
        y, ahYear.length, ahYear.reduce((s, p) => s + p.totalUnits, 0),
        clYear.length, clYear.reduce((s, p) => s + p.loanAmount, 0),
      ]);
    });

    analyticsData.push(['']);
    analyticsData.push(['AMI LEVEL DISTRIBUTION']);
    analyticsData.push(['AMI Level', 'Units', '% of Total']);
    const amiLevels = [
      { level: '30% AMI (Extreme Low Income)', key: 'ami30' as const },
      { level: '40% AMI (Very Low Income)', key: 'ami40' as const },
      { level: '50% AMI (Low Income)', key: 'ami50' as const },
      { level: '60% AMI (Moderate Income)', key: 'ami60' as const },
      { level: '70% AMI (Upper Moderate)', key: 'ami70' as const },
      { level: '80% AMI (Middle Income)', key: 'ami80' as const },
    ];
    const totalAMI = filteredAH.reduce((s, p) => s + p.ami30 + p.ami40 + p.ami50 + p.ami60 + p.ami70 + p.ami80, 0);
    amiLevels.forEach(({ level, key }) => {
      const units = filteredAH.reduce((s, p) => s + p[key], 0);
      if (units > 0) analyticsData.push([level, units, `${((units / totalAMI) * 100).toFixed(1)}%`]);
    });

    analyticsData.push(['']);
    analyticsData.push(['COMMERCIAL LOAN TYPE BREAKDOWN']);
    analyticsData.push(['Loan Type', 'Count', 'Total Value', 'Avg LTV', 'Avg DSCR']);
    const loanTypeBreakdown: Record<string, { count: number; value: number; ltv: number; dscr: number }> = {};
    filteredCL.forEach(p => {
      if (!loanTypeBreakdown[p.loanType]) loanTypeBreakdown[p.loanType] = { count: 0, value: 0, ltv: 0, dscr: 0 };
      loanTypeBreakdown[p.loanType].count++;
      loanTypeBreakdown[p.loanType].value += p.loanAmount;
      loanTypeBreakdown[p.loanType].ltv += p.ltv;
      loanTypeBreakdown[p.loanType].dscr += p.dscr;
    });
    Object.entries(loanTypeBreakdown).forEach(([type, data]) => {
      analyticsData.push([type, data.count, data.value, (data.ltv / data.count).toFixed(1), (data.dscr / data.count).toFixed(2)]);
    });

    analyticsData.push(['']);
    analyticsData.push(['PROPERTY TYPE BREAKDOWN (Commercial)']);
    analyticsData.push(['Property Type', 'Count', 'Total Value', 'Avg Occupancy', 'Avg Cap Rate']);
    const propTypeBreakdown: Record<string, { count: number; value: number; occ: number; cap: number }> = {};
    filteredCL.forEach(p => {
      if (!propTypeBreakdown[p.propertyType]) propTypeBreakdown[p.propertyType] = { count: 0, value: 0, occ: 0, cap: 0 };
      propTypeBreakdown[p.propertyType].count++;
      propTypeBreakdown[p.propertyType].value += p.loanAmount;
      propTypeBreakdown[p.propertyType].occ += p.occupancyRate;
      propTypeBreakdown[p.propertyType].cap += p.capRate;
    });
    Object.entries(propTypeBreakdown).forEach(([type, data]) => {
      analyticsData.push([type, data.count, data.value, (data.occ / data.count).toFixed(1), (data.cap / data.count).toFixed(2)]);
    });

    analyticsData.push(['']);
    analyticsData.push(['DISTRESS ANALYSIS']);
    analyticsData.push(['Distress Level', 'Count', 'Total Loan Value', 'Avg LTV', 'Avg DSCR', 'Avg Occupancy']);
    ['Critical', 'High', 'Moderate', 'Low'].forEach(level => {
      const props = filteredCL.filter(p => p.distressLevel === level);
      if (props.length > 0) {
        analyticsData.push([
          level, props.length,
          props.reduce((s, p) => s + p.loanAmount, 0),
          (props.reduce((s, p) => s + p.ltv, 0) / props.length).toFixed(1),
          (props.reduce((s, p) => s + p.dscr, 0) / props.length).toFixed(2),
          (props.reduce((s, p) => s + p.occupancyRate, 0) / props.length).toFixed(1),
        ]);
      }
    });

    const wsAnalytics = XLSX.utils.aoa_to_sheet(analyticsData);
    autoSizeColumns(wsAnalytics, 60);
    XLSX.utils.book_append_sheet(wb, wsAnalytics, 'Analytics');
  }

  // ===== SHEET 6: DATA DICTIONARY =====
  const dictData = [
    ['DATA DICTIONARY — FIELD DEFINITIONS'],
    [''],
    ['AFFORDABLE HOUSING FIELDS'],
    ['Field', 'Description'],
    ['Property Name', 'Name of the affordable housing property'],
    ['Address', 'Street address'],
    ['City / County', 'Location within Oregon'],
    ['Expiration Date', 'Date when land use restriction / regulatory agreement expires'],
    ['Total Units', 'Total number of housing units'],
    ['Restricted Units', 'Number of units subject to affordability restrictions'],
    ['Funding Source', 'Primary funding mechanism (LIHTC, HUD Section 8, USDA RD, or combination)'],
    ['OHCS Funded', 'Whether property received Oregon Housing & Community Services funding'],
    ['HUD / USDA', 'Federal program participation'],
    ['30-80% AMI Units', 'Unit count at each Area Median Income level'],
    ['Risk Level', 'Computed risk: High (expiring soon, no preservation), Medium (renewal in process), Low (government owned/ROFR)'],
    ['Investment Score', 'Proprietary 1-100 score based on unit count, urgency, funding source, and risk'],
    ['Preservation Status', 'Current status of preservation efforts (ROFR, Government Owned, Renewal In Process, etc.)'],
    [''],
    ['COMMERCIAL LOAN FIELDS'],
    ['Field', 'Description'],
    ['Loan Amount', 'Outstanding principal balance'],
    ['Maturity Date', 'Date when loan balloon payment is due'],
    ['Lender', 'Loan servicer / holder'],
    ['Loan Type', 'CMBS, Portfolio, Bridge, Agency (Fannie/Freddie), SBA 504, Construction-to-Perm, etc.'],
    ['Interest Rate', 'Current note rate'],
    ['LTV (Loan-to-Value)', 'Current loan balance as % of estimated property value. >80% = elevated risk'],
    ['DSCR (Debt Service Coverage Ratio)', 'NOI / Annual Debt Service. <1.0 = negative cash flow, <1.2 = tight'],
    ['Occupancy Rate', 'Current physical occupancy percentage'],
    ['Cap Rate', 'NOI / Property Value. Higher = potentially more distressed'],
    ['NOI (Net Operating Income)', 'Annual income after operating expenses'],
    ['Distress Level', 'Computed: Critical (LTV>85% or DSCR<0.9), High (LTV>75% or DSCR<1.0), Moderate, Low'],
    ['Investment Score', 'Proprietary 1-100 score based on loan size, distress, LTV, occupancy, urgency'],
    ['Conversion Potential', 'Adaptive reuse opportunity (office-to-residential, redevelopment, etc.)'],
  ];
  const wsDict = XLSX.utils.aoa_to_sheet(dictData);
  autoSizeColumns(wsDict, 80);
  XLSX.utils.book_append_sheet(wb, wsDict, 'Data Dictionary');

  // Generate file
  const timestamp = new Date().toISOString().slice(0, 10);
  const fileName = `OffMarket_Sourcing_Report_${timestamp}.xlsx`;
  XLSX.writeFile(wb, fileName, { bookType: 'xlsx' });
  return fileName;
}
