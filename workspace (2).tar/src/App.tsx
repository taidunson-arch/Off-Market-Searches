import { useState, useMemo } from 'react';
import { affordableHousingData, getUniqueCounties, getUniqueYears, getUniqueFundingSources } from './data/affordableHousingData';
import { commercialLoanMaturities, getUniquePropertyTypes, getMaturityYears } from './data/commercialLoanData';
import type { AffordableHousingProperty } from './data/affordableHousingData';
import type { CommercialLoanMaturity } from './data/commercialLoanData';

type TabType = 'dashboard' | 'affordable' | 'commercial' | 'combined';

function formatCurrency(value: number): string {
  if (value >= 1000000) {
    return `$${(value / 1000000).toFixed(1)}M`;
  }
  return `$${(value / 1000).toFixed(0)}K`;
}

function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function RiskBadge({ level }: { level: string }) {
  const colors: Record<string, string> = {
    High: 'bg-red-100 text-red-800 border-red-200',
    Critical: 'bg-red-200 text-red-900 border-red-300',
    Medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    Moderate: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    Low: 'bg-green-100 text-green-800 border-green-200',
  };
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${colors[level] || 'bg-gray-100 text-gray-800'}`}>
      {level}
    </span>
  );
}

function FundingBadge({ source }: { source: string }) {
  const colors: Record<string, string> = {
    LIHTC: 'bg-blue-100 text-blue-800',
    HUD: 'bg-purple-100 text-purple-800',
    USDA: 'bg-emerald-100 text-emerald-800',
    OHCS: 'bg-indigo-100 text-indigo-800',
    Other: 'bg-gray-100 text-gray-800',
  };
  const key = source.includes('LIHTC') ? 'LIHTC' : source.includes('HUD') ? 'HUD' : source.includes('USDA') ? 'USDA' : source.includes('OHCS') ? 'OHCS' : 'Other';
  return (
    <span className={`px-2 py-0.5 rounded text-xs font-medium ${colors[key] || colors.Other}`}>
      {source}
    </span>
  );
}

// Dashboard Component
function Dashboard() {
  const totalAffordableUnits = affordableHousingData.reduce((sum, p) => sum + p.totalUnits, 0);
  const totalCommercialLoanValue = commercialLoanMaturities.reduce((sum, p) => sum + p.loanAmount, 0);
  const highRiskAffordable = affordableHousingData.filter(p => p.riskLevel === 'High').length;
  const criticalCommercial = commercialLoanMaturities.filter(p => p.distressLevel === 'Critical').length;
  const expiring2026 = affordableHousingData.filter(p => p.expirationYear === 2026).length;
  const maturing2026 = commercialLoanMaturities.filter(p => p.maturityYear === 2026).length;

  // Year-by-year breakdown for affordable housing
  const yearBreakdown = useMemo(() => {
    const breakdown: Record<number, { count: number; units: number }> = {};
    affordableHousingData.forEach(p => {
      if (!breakdown[p.expirationYear]) breakdown[p.expirationYear] = { count: 0, units: 0 };
      breakdown[p.expirationYear].count++;
      breakdown[p.expirationYear].units += p.totalUnits;
    });
    return breakdown;
  }, []);

  // County breakdown
  const countyBreakdown = useMemo(() => {
    const breakdown: Record<string, number> = {};
    affordableHousingData.forEach(p => {
      breakdown[p.county] = (breakdown[p.county] || 0) + p.totalUnits;
    });
    return Object.entries(breakdown).sort((a, b) => b[1] - a[1]).slice(0, 10);
  }, []);

  // Commercial by property type
  const typeBreakdown = useMemo(() => {
    const breakdown: Record<string, { count: number; value: number }> = {};
    commercialLoanMaturities.forEach(p => {
      if (!breakdown[p.propertyType]) breakdown[p.propertyType] = { count: 0, value: 0 };
      breakdown[p.propertyType].count++;
      breakdown[p.propertyType].value += p.loanAmount;
    });
    return Object.entries(breakdown).sort((a, b) => b[1].value - a[1].value);
  }, []);

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 font-medium">Total Affordable Units at Risk</p>
              <p className="text-3xl font-bold text-gray-900 mt-1">{totalAffordableUnits.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-2">{affordableHousingData.length} properties tracked</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 font-medium">Commercial Loans Maturing</p>
              <p className="text-3xl font-bold text-gray-900 mt-1">{formatCurrency(totalCommercialLoanValue)}</p>
            </div>
            <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-2">{commercialLoanMaturities.length} loans tracked (2026-2030)</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 font-medium">High-Risk Leads</p>
              <p className="text-3xl font-bold text-red-600 mt-1">{highRiskAffordable + criticalCommercial}</p>
            </div>
            <div className="w-12 h-12 bg-red-50 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-2">{highRiskAffordable} affordable + {criticalCommercial} commercial</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 font-medium">2026 Expirations/Maturities</p>
              <p className="text-3xl font-bold text-amber-600 mt-1">{expiring2026 + maturing2026}</p>
            </div>
            <div className="w-12 h-12 bg-amber-50 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-2">{expiring2026} affordable + {maturing2026} commercial</p>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Affordable Housing Expiration Timeline */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Affordable Housing Expiration Timeline</h3>
          <div className="space-y-3">
            {Object.entries(yearBreakdown).sort().map(([year, data]) => (
              <div key={year} className="flex items-center gap-3">
                <span className="text-sm font-medium text-gray-600 w-12">{year}</span>
                <div className="flex-1 bg-gray-100 rounded-full h-6 relative overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-end pr-2"
                    style={{ width: `${Math.max((data.units / 2000) * 100, 8)}%` }}
                  >
                    <span className="text-xs text-white font-medium">{data.units}</span>
                  </div>
                </div>
                <span className="text-xs text-gray-500 w-16 text-right">{data.count} props</span>
              </div>
            ))}
          </div>
        </div>

        {/* Commercial Loans by Property Type */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Commercial Loans by Property Type</h3>
          <div className="space-y-3">
            {typeBreakdown.map(([type, data]) => (
              <div key={type} className="flex items-center gap-3">
                <span className="text-sm font-medium text-gray-600 w-32 truncate" title={type}>{type}</span>
                <div className="flex-1 bg-gray-100 rounded-full h-6 relative overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-orange-400 to-orange-600 rounded-full flex items-center justify-end pr-2"
                    style={{ width: `${Math.max((data.value / 55000000) * 100, 10)}%` }}
                  >
                    <span className="text-xs text-white font-medium">{formatCurrency(data.value)}</span>
                  </div>
                </div>
                <span className="text-xs text-gray-500 w-12 text-right">{data.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* County Breakdown & Distress Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Counties by Units at Risk</h3>
          <div className="space-y-2">
            {countyBreakdown.map(([county, units]) => (
              <div key={county} className="flex items-center justify-between py-1.5 border-b border-gray-50 last:border-0">
                <span className="text-sm text-gray-700">{county}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 bg-gray-100 rounded-full h-2">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: `${(units / countyBreakdown[0][1]) * 100}%` }}></div>
                  </div>
                  <span className="text-sm font-medium text-gray-900 w-12 text-right">{units}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Commercial Distress Summary</h3>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="bg-red-50 rounded-lg p-3 text-center">
              <p className="text-2xl font-bold text-red-700">{commercialLoanMaturities.filter(p => p.distressLevel === 'Critical').length}</p>
              <p className="text-xs text-red-600">Critical</p>
            </div>
            <div className="bg-orange-50 rounded-lg p-3 text-center">
              <p className="text-2xl font-bold text-orange-700">{commercialLoanMaturities.filter(p => p.distressLevel === 'High').length}</p>
              <p className="text-xs text-orange-600">High</p>
            </div>
            <div className="bg-yellow-50 rounded-lg p-3 text-center">
              <p className="text-2xl font-bold text-yellow-700">{commercialLoanMaturities.filter(p => p.distressLevel === 'Moderate').length}</p>
              <p className="text-xs text-yellow-600">Moderate</p>
            </div>
            <div className="bg-green-50 rounded-lg p-3 text-center">
              <p className="text-2xl font-bold text-green-700">{commercialLoanMaturities.filter(p => p.distressLevel === 'Low').length}</p>
              <p className="text-xs text-green-600">Low</p>
            </div>
          </div>
          <div className="border-t pt-3">
            <h4 className="text-sm font-medium text-gray-700 mb-2">Critical Distress Properties</h4>
            <div className="space-y-2">
              {commercialLoanMaturities.filter(p => p.distressLevel === 'Critical').map(p => (
                <div key={p.id} className="flex items-center justify-between text-sm">
                  <span className="text-gray-700 truncate flex-1">{p.propertyName}</span>
                  <span className="text-gray-500 ml-2">{formatDate(p.loanMaturityDate)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Affordable Housing Tab
function AffordableHousingTab() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedYear, setSelectedYear] = useState<number | 'all'>('all');
  const [selectedCounty, setSelectedCounty] = useState<string>('all');
  const [selectedFunding, setSelectedFunding] = useState<string>('all');
  const [selectedRisk, setSelectedRisk] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('expirationDate');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  const counties = getUniqueCounties();
  const years = getUniqueYears();
  const fundingSources = getUniqueFundingSources();

  const filteredData = useMemo(() => {
    let data = [...affordableHousingData];

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      data = data.filter(p =>
        p.propertyName.toLowerCase().includes(term) ||
        p.city.toLowerCase().includes(term) ||
        p.address.toLowerCase().includes(term) ||
        p.county.toLowerCase().includes(term)
      );
    }
    if (selectedYear !== 'all') data = data.filter(p => p.expirationYear === selectedYear);
    if (selectedCounty !== 'all') data = data.filter(p => p.county === selectedCounty);
    if (selectedFunding !== 'all') data = data.filter(p => p.fundingSource === selectedFunding);
    if (selectedRisk !== 'all') data = data.filter(p => p.riskLevel === selectedRisk);

    data.sort((a, b) => {
      let valA: any, valB: any;
      switch (sortBy) {
        case 'expirationDate': valA = a.expirationDate; valB = b.expirationDate; break;
        case 'propertyName': valA = a.propertyName; valB = b.propertyName; break;
        case 'totalUnits': valA = a.totalUnits; valB = b.totalUnits; break;
        case 'city': valA = a.city; valB = b.city; break;
        default: valA = a.expirationDate; valB = b.expirationDate;
      }
      if (typeof valA === 'number') return sortDir === 'asc' ? valA - valB : valB - valA;
      return sortDir === 'asc' ? String(valA).localeCompare(String(valB)) : String(valB).localeCompare(String(valA));
    });

    return data;
  }, [searchTerm, selectedYear, selectedCounty, selectedFunding, selectedRisk, sortBy, sortDir]);

  const handleSort = (field: string) => {
    if (sortBy === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortBy(field); setSortDir('asc'); }
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1 block">Search</label>
            <input
              type="text"
              placeholder="Property, city, address..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1 block">Expiration Year</label>
            <select value={selectedYear} onChange={e => setSelectedYear(e.target.value === 'all' ? 'all' : Number(e.target.value))} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
              <option value="all">All Years</option>
              {years.map(y => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1 block">County</label>
            <select value={selectedCounty} onChange={e => setSelectedCounty(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
              <option value="all">All Counties</option>
              {counties.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1 block">Funding Source</label>
            <select value={selectedFunding} onChange={e => setSelectedFunding(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
              <option value="all">All Sources</option>
              {fundingSources.map(f => <option key={f} value={f}>{f}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1 block">Risk Level</label>
            <select value={selectedRisk} onChange={e => setSelectedRisk(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
              <option value="all">All Levels</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>
        <div className="mt-3 flex items-center justify-between">
          <p className="text-sm text-gray-500">{filteredData.length} properties found • {filteredData.reduce((s, p) => s + p.totalUnits, 0).toLocaleString()} total units</p>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-4 py-3 font-medium text-gray-600 cursor-pointer hover:text-gray-900" onClick={() => handleSort('expirationDate')}>
                  Expiration Date {sortBy === 'expirationDate' && (sortDir === 'asc' ? '↑' : '↓')}
                </th>
                <th className="text-left px-4 py-3 font-medium text-gray-600 cursor-pointer hover:text-gray-900" onClick={() => handleSort('propertyName')}>
                  Property {sortBy === 'propertyName' && (sortDir === 'asc' ? '↑' : '↓')}
                </th>
                <th className="text-left px-4 py-3 font-medium text-gray-600 cursor-pointer hover:text-gray-900" onClick={() => handleSort('city')}>
                  City/County {sortBy === 'city' && (sortDir === 'asc' ? '↑' : '↓')}
                </th>
                <th className="text-left px-4 py-3 font-medium text-gray-600 cursor-pointer hover:text-gray-900" onClick={() => handleSort('totalUnits')}>
                  Units {sortBy === 'totalUnits' && (sortDir === 'asc' ? '↑' : '↓')}
                </th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Funding</th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Risk</th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredData.map((property) => (
                <tr key={property.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-gray-700 whitespace-nowrap">{formatDate(property.expirationDate)}</td>
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-900">{property.propertyName}</p>
                    <p className="text-xs text-gray-500">{property.address}</p>
                  </td>
                  <td className="px-4 py-3">
                    <p className="text-gray-700">{property.city}</p>
                    <p className="text-xs text-gray-500">{property.county}</p>
                  </td>
                  <td className="px-4 py-3 font-medium text-gray-900">{property.totalUnits}</td>
                  <td className="px-4 py-3"><FundingBadge source={property.fundingSource} /></td>
                  <td className="px-4 py-3"><RiskBadge level={property.riskLevel} /></td>
                  <td className="px-4 py-3 text-xs text-gray-600 max-w-48 truncate">{property.preservationStatus || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// Commercial Loan Maturities Tab
function CommercialLoanTab() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedYear, setSelectedYear] = useState<number | 'all'>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedDistress, setSelectedDistress] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('loanMaturityDate');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  const propertyTypes = getUniquePropertyTypes();
  const maturityYears = getMaturityYears();

  const filteredData = useMemo(() => {
    let data = [...commercialLoanMaturities];

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      data = data.filter(p =>
        p.propertyName.toLowerCase().includes(term) ||
        p.city.toLowerCase().includes(term) ||
        p.lender.toLowerCase().includes(term) ||
        p.propertyType.toLowerCase().includes(term)
      );
    }
    if (selectedYear !== 'all') data = data.filter(p => p.maturityYear === selectedYear);
    if (selectedType !== 'all') data = data.filter(p => p.propertyType === selectedType);
    if (selectedDistress !== 'all') data = data.filter(p => p.distressLevel === selectedDistress);

    data.sort((a, b) => {
      let valA: any, valB: any;
      switch (sortBy) {
        case 'loanMaturityDate': valA = a.loanMaturityDate; valB = b.loanMaturityDate; break;
        case 'propertyName': valA = a.propertyName; valB = b.propertyName; break;
        case 'loanAmount': valA = a.loanAmount; valB = b.loanAmount; break;
        case 'ltv': valA = a.ltv; valB = b.ltv; break;
        default: valA = a.loanMaturityDate; valB = b.loanMaturityDate;
      }
      if (typeof valA === 'number') return sortDir === 'asc' ? valA - valB : valB - valA;
      return sortDir === 'asc' ? String(valA).localeCompare(String(valB)) : String(valB).localeCompare(String(valA));
    });

    return data;
  }, [searchTerm, selectedYear, selectedType, selectedDistress, sortBy, sortDir]);

  const handleSort = (field: string) => {
    if (sortBy === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortBy(field); setSortDir('asc'); }
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1 block">Search</label>
            <input
              type="text"
              placeholder="Property, city, lender..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1 block">Maturity Year</label>
            <select value={selectedYear} onChange={e => setSelectedYear(e.target.value === 'all' ? 'all' : Number(e.target.value))} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
              <option value="all">All Years</option>
              {maturityYears.map(y => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1 block">Property Type</label>
            <select value={selectedType} onChange={e => setSelectedType(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
              <option value="all">All Types</option>
              {propertyTypes.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1 block">Distress Level</label>
            <select value={selectedDistress} onChange={e => setSelectedDistress(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
              <option value="all">All Levels</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Moderate">Moderate</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>
        <div className="mt-3 flex items-center justify-between">
          <p className="text-sm text-gray-500">{filteredData.length} loans found • {formatCurrency(filteredData.reduce((s, p) => s + p.loanAmount, 0))} total value</p>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-4 py-3 font-medium text-gray-600 cursor-pointer hover:text-gray-900" onClick={() => handleSort('loanMaturityDate')}>
                  Maturity {sortBy === 'loanMaturityDate' && (sortDir === 'asc' ? '↑' : '↓')}
                </th>
                <th className="text-left px-4 py-3 font-medium text-gray-600 cursor-pointer hover:text-gray-900" onClick={() => handleSort('propertyName')}>
                  Property {sortBy === 'propertyName' && (sortDir === 'asc' ? '↑' : '↓')}
                </th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Type</th>
                <th className="text-left px-4 py-3 font-medium text-gray-600 cursor-pointer hover:text-gray-900" onClick={() => handleSort('loanAmount')}>
                  Loan Amt {sortBy === 'loanAmount' && (sortDir === 'asc' ? '↑' : '↓')}
                </th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Lender</th>
                <th className="text-left px-4 py-3 font-medium text-gray-600 cursor-pointer hover:text-gray-900" onClick={() => handleSort('ltv')}>
                  LTV {sortBy === 'ltv' && (sortDir === 'asc' ? '↑' : '↓')}
                </th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Occ %</th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Distress</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredData.map((loan) => (
                <tr key={loan.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-gray-700 whitespace-nowrap">{formatDate(loan.loanMaturityDate)}</td>
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-900">{loan.propertyName}</p>
                    <p className="text-xs text-gray-500">{loan.city}, {loan.county}</p>
                  </td>
                  <td className="px-4 py-3">
                    <span className="px-2 py-0.5 bg-gray-100 rounded text-xs font-medium text-gray-700">{loan.propertyType}</span>
                  </td>
                  <td className="px-4 py-3 font-medium text-gray-900">{formatCurrency(loan.loanAmount)}</td>
                  <td className="px-4 py-3 text-gray-700 text-xs">{loan.lender}</td>
                  <td className="px-4 py-3">
                    <span className={`font-medium ${loan.ltv >= 80 ? 'text-red-600' : loan.ltv >= 70 ? 'text-yellow-600' : 'text-green-600'}`}>
                      {loan.ltv}%
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`font-medium ${loan.occupancyRate < 70 ? 'text-red-600' : loan.occupancyRate < 85 ? 'text-yellow-600' : 'text-green-600'}`}>
                      {loan.occupancyRate}%
                    </span>
                  </td>
                  <td className="px-4 py-3"><RiskBadge level={loan.distressLevel} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// Combined Leads Tab
function CombinedLeadsTab() {
  const [filterType, setFilterType] = useState<'all' | 'affordable' | 'commercial'>('all');
  const [distressOnly, setDistressOnly] = useState(false);

  interface CombinedLead {
    id: string;
    source: 'affordable' | 'commercial';
    name: string;
    location: string;
    date: string;
    year: number;
    units: number;
    value?: number;
    risk: string;
    detail: string;
  }

  const combinedLeads: CombinedLead[] = useMemo(() => {
    const leads: CombinedLead[] = [];

    affordableHousingData.forEach(p => {
      leads.push({
        id: `AH-${p.id}`,
        source: 'affordable',
        name: p.propertyName,
        location: `${p.city}, ${p.county}`,
        date: p.expirationDate,
        year: p.expirationYear,
        units: p.totalUnits,
        risk: p.riskLevel,
        detail: `${p.fundingSource} • ${p.totalUnits} units expiring`,
      });
    });

    commercialLoanMaturities.forEach(p => {
      leads.push({
        id: `CL-${p.id}`,
        source: 'commercial',
        name: p.propertyName,
        location: `${p.city}, ${p.county}`,
        date: p.loanMaturityDate,
        year: p.maturityYear,
        units: p.units,
        value: p.loanAmount,
        risk: p.distressLevel,
        detail: `${p.propertyType} • ${formatCurrency(p.loanAmount)} loan maturing`,
      });
    });

    return leads.sort((a, b) => a.date.localeCompare(b.date));
  }, []);

  const filtered = useMemo(() => {
    let data = [...combinedLeads];
    if (filterType !== 'all') data = data.filter(l => l.source === filterType);
    if (distressOnly) data = data.filter(l => l.risk === 'High' || l.risk === 'Critical');
    return data;
  }, [combinedLeads, filterType, distressOnly]);

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex rounded-lg border border-gray-300 overflow-hidden">
            <button onClick={() => setFilterType('all')} className={`px-4 py-2 text-sm font-medium ${filterType === 'all' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}>All Leads</button>
            <button onClick={() => setFilterType('affordable')} className={`px-4 py-2 text-sm font-medium ${filterType === 'affordable' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}>Affordable Housing</button>
            <button onClick={() => setFilterType('commercial')} className={`px-4 py-2 text-sm font-medium ${filterType === 'commercial' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}>Commercial Loans</button>
          </div>
          <label className="flex items-center gap-2 text-sm text-gray-700">
            <input type="checkbox" checked={distressOnly} onChange={e => setDistressOnly(e.target.checked)} className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
            High/Critical Distress Only
          </label>
          <span className="text-sm text-gray-500 ml-auto">{filtered.length} leads</span>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Date</th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Source</th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Property</th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Location</th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Details</th>
                <th className="text-left px-4 py-3 font-medium text-gray-600">Risk</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map((lead) => (
                <tr key={lead.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-gray-700 whitespace-nowrap">{formatDate(lead.date)}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${lead.source === 'affordable' ? 'bg-blue-100 text-blue-800' : 'bg-orange-100 text-orange-800'}`}>
                      {lead.source === 'affordable' ? '🏠 Affordable' : '🏢 Commercial'}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-medium text-gray-900">{lead.name}</td>
                  <td className="px-4 py-3 text-gray-600">{lead.location}</td>
                  <td className="px-4 py-3 text-xs text-gray-600">{lead.detail}</td>
                  <td className="px-4 py-3"><RiskBadge level={lead.risk} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// Main App
export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');

  const tabs: { id: TabType; label: string; icon: string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'affordable', label: 'Affordable Housing', icon: '🏠' },
    { id: 'commercial', label: 'Loan Maturities', icon: '🏢' },
    { id: 'combined', label: 'Combined Leads', icon: '📋' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-900">Off-Market Sourcing System</h1>
                <p className="text-xs text-gray-500 -mt-0.5">Affordable Housing Restrictions & Loan Maturity Tracker</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-400">Oregon Market • Updated Oct 2026</span>
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-1 overflow-x-auto">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <span>{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'affordable' && <AffordableHousingTab />}
        {activeTab === 'commercial' && <CommercialLoanTab />}
        {activeTab === 'combined' && <CombinedLeadsTab />}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-2">
            <p className="text-xs text-gray-500">
              Data sources: OHCS Affordable Housing Inventory, HUD/USDA Contract Expirations, Commercial Loan Records
            </p>
            <p className="text-xs text-gray-400">
              System covers properties with land use restrictions expiring & commercial loans maturing through 2031
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
